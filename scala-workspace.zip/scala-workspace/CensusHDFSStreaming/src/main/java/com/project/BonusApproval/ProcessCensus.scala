package com.project.BonusApproval

import org.apache.spark.SparkConf
import org.apache.spark.streaming._
import org.apache.spark.sql._
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SQLImplicits

object ProcessCensus {
  
  //Create a class to represent the schema
  case class CensusData( DisplayID:Int, EmploymentType:String,EduQualification:String, MaritalStatus:String,JobType:String,WorkingHoursPerWeek:Int,Country:String,Salary:String)
  
  def main(args: Array[String]) {
    
    //validating number of command line arguments.
    if (args.length < 1) {
      System.err.println("Please provide HDFS folder path")
      System.exit(1)
    }
    
    // Create Streaming context with 10 second batch interval
    val sparkConf = new SparkConf().setAppName("SparkStreamingHDFSKafkaBonusnalysis")
    
    val ssc = new StreamingContext(sparkConf, Seconds(10))
    
    //consume the messages from HDFS folder and create DStream
    
    //args(0) - HDFS folder path
    val LogsStream = ssc.textFileStream(args(0))
    
    //Collecting the records for window period of 60seconds and sliding interval time 20 seconds
    val windowedLogsStream = LogsStream.window(Seconds(60),Seconds(20));
    
    //create SQL context object to perform SQL operations
    val sqlContext = new org.apache.spark.sql.SQLContext(ssc.sparkContext)
    
    import sqlContext.implicits._
    
    //Process each RDD of stream and detect fraud.  
   windowedLogsStream.foreachRDD(
       
       rdd =>
   {
   //converting RDD in to Dataframe
   val df = rdd.map(x => x.split(",")).map { c  => CensusData(c(0).trim.toInt, c(1), c(2), c(3), c(4), c(5).trim.toInt, c(6), c(7)) }.toDF()
   
   df.registerTempTable("CensusData")
   
   //writing SQL query on Dataframe to detect fraud.
    val fraudDF = sqlContext.sql("Select * from CensusData where MaritalStatus = 'Unmarried' and EmploymentType = 'SelfEmplo'");
   //display customer details to whom fraud alert has to be sent
    fraudDF.show();
    
    }
   )
    
   //Start the Streaming application
   ssc.start()
   
   ssc.awaitTermination()
   
  }
  
}
